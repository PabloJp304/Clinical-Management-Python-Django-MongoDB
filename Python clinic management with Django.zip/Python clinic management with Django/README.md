## TendenciasJuanOssaAndresArrubla

# Instalación
Para ejecutar esta aplicación, tener instaladas las siguientes bibliotecas de Python:

- Django
- Django Rest Framework
- ReportLab
- Requests

Instalar estas bibliotecas utilizando pip:
- pip install django djangorestframework reportlab requests

# Uso
Datos de ingreso

- Médico:
  
   - Nombre de usuario: wiliam_osler
   - Contraseña: E=i4P&55uN&2
 
 - Enfermera:
  
   - Nombre de usuario: jennifer_lawrence
   - Contraseña: KQ73}Or48mC@

- Recursos Humanos (RRHH):
  
   - Nombre de usuario: scarlett_johansson
   - Contraseña: wE6h\Cw55`Kg
 
- Personal Administrativo (PPAA):
  
   - Nombre de usuario: canco_rodriguez
   - Contraseña: L#y$]2v9D83£
 
- Soporte de Información (SSII):
   - Nombre de usuario: laura_escanes
   - Contraseña: y248(yNi7&61
    
