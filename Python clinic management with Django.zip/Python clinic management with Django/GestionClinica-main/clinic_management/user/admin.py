from django.contrib import admin
from .models import Role,Usuario

# Register your models here.

admin.site.register(Usuario)
admin.site.register(Role)